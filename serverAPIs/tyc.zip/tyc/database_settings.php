<?
$database_hostaddress = "localhost";
$database_username = "yunizcom_stanly";
$database_password = "Admin219";
$database_name = "yunizcom_mtapp";
?>