<?
if($protect_key!="yuniz_lansy"){exit("Invalid Operation! Please contact system administrator.");} // include this on all modules page 1st line for script protection.
//----------module own page setting--------------
$page = $_GET['page'];
$levels = $_GET['levels'];
if($page == null){$page = 1;}
if($levels == null){$levels = 0;}
$page--;
$page = $page * 10;
$counter = $page + 1;
$loadedLines = 0;
//----------module own page setting--------------
$hallOfFame = "";
if($levels == 0){
	$results= mysql_query("SELECT nickname,scores,levels,fbid from t_scoresTYC GROUP BY nickname,uid,levels ORDER BY scores desc,levels desc,tdate desc LIMIT ".$page.",10");
}else{	
	$results= mysql_query("SELECT nickname,scores,levels,fbid from t_scoresTYC WHERE levels = '".$levels."' GROUP BY nickname,uid,levels ORDER BY scores desc,levels desc,tdate desc LIMIT ".$page.",10");
}

if(mysql_Numrows($results)>0){
	while ($row = mysql_fetch_array($results)) {
		$hallOfFame.= '{"no":"'.$counter.'","n":"'.substr(trim($row['nickname']),0,20).'","s":"'.$row['scores'].'","l":"'.$row['levels'].'","fb":"'.$row['fbid'].'"},';
		$counter++;
		$loadedLines++;
	}
	
	for($ii = $loadedLines;$ii<10;$ii++){
		$hallOfFame.= '{"no":"","n":"","s":"","l":"","fb":""},';
	}
	
	$hallOfFame.= '{"no":"","n":"","s":"","l":"","fb":""}';
}
?>
{
	"hallOfFame": [<?=$hallOfFame?>]
}